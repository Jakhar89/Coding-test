#!/bin/bash
# A simple menu system
red=$'\e[1;31m'
grn=$'\e[1;32m'
blu=$'\e[1;34m'
mag=$'\e[1;35m'
cyn=$'\e[1;36m'
white=$'\e[0m'
reset="tput sgr0"
names='build SSCP-FE-Package SSCP-B&D SSCP-Pub-B&D DXPDLO-B&D DXPDLO-FE-Package QUIT-Select-this-to-quit runScript chromeDebug'

PS3=$grn'Select character:'
$reset

select name in $names
do
$reset
if [ $name == 'QUIT-Select-this-to-quit' ]

then
break
fi

if [ $name == 'build' ]

then
    cd digital-aem-sscp
    
    echo $mag"ONLY Building SSCP ..."
    echo ' '
    mvn clean install -Denforcer.skip=true 
    cd ../
fi

if [ $name == 'SSCP-FE-Package' ]

then
    cd digital-aem-sscp/ui.frontend
   
    echo $blu"Building and deploying FE Package only ..."
    echo ' '
    mvn clean install -PautoInstallPackage -Denforcer.skip=true
    #mvn -U clean install -D"checkstyle.skip" -PautoInstallPackagePublish -Padobe-public
    cd ../../
    ls
    
fi

if [ $name == 'SSCP-B&D' ]

then
    cd digital-aem-sscp
    
    echo $blu"Building and deploying SSCP Author..."
    echo ' '
    mvn clean install -PautoInstallPackage -Denforcer.skip=true
    #mvn clean install -PautoInstallSinglePackage -Denforcer.skip=true
    #mvn -U clean install -D"checkstyle.skip"=true -PautoInstallPackage -Padobe-public
    cd ../
    ls
fi

if [ $name == 'SSCP-Pub-B&D' ]

then
    cd digital-aem-sscp
   
    echo $blu"Building and deploying Publish ..."
    echo ' '
    mvn clean install -PautoInstallPackagePublish -Denforcer.skip=true
    #mvn -U clean install -D"checkstyle.skip" -PautoInstallPackagePublish -Padobe-public
    cd ../
    
fi

if [ $name == 'DXPDLO-B&D' ]

then
    cd digital-aem-tfal
    
    echo $blu"Building and deploying DXP DLO Author..."
    echo ' '
    mvn clean install -PautoInstallPackage -P adobe-public,fedDev
    #mvn clean install -PautoInstallSinglePackage -Denforcer.skip=true
    #mvn -U clean install -D"checkstyle.skip"=true -PautoInstallPackage -Padobe-public
    cd ../
    ls
fi

if [ $name == 'DXPDLO-FE-Package' ]

then
    cd digital-aem-tfal/ui.frontend
   
    echo $blu"Building and deploying DXP DLO FE Package only ..."
    echo ' '
    mvn clean install -PautoInstallPackage -P adobe-public,fedDev
    #mvn -U clean install -D"checkstyle.skip" -PautoInstallPackagePublish -Padobe-public
    cd ../../
    ls
    
fi

if [ $name == 'runScript' ]

then
    ls
    echo $red"Type Script below to run ..."
    read varname
    $varname
    
fi

if [ $name == 'chromeDebug' ]

then
    echo 'Starting Chrome in Debug Mode with Port 9222'
    "C:/Program Files/Google/Chrome/Application/chrome.exe" --remote-debugging-port=9222 &
fi

$reset
done
echo $red' Qutting...'
echo ' '
$reset